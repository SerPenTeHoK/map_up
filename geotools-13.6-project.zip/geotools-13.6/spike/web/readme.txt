This spike directory contains the content of the geotools website located at http://wiki.osgeo.org/wiki/SAC_Service_Status

The idea is to do an svn checkout on the above server when the website needs to be refreshed.