package org.osgeo.geometry;

/**
 * SimpleGeometryBuilder that is method compatible with the deegree requirements.
 * 
 * @author Jody Garnett
 */
public class GeometryBuilder {

}
