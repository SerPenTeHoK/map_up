package org.osgeo.geometry;

/**
 * GeometryBuilder that is method compatible with the deegree requirements.
 * 
 * @author Jody Garnett
 */
public class SimpleGeometryBuilder {

}
